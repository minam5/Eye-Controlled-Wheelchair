class WheelChairController:

    def __init__(self):
        self.sig_error_reset() #immediately turn on error light until everything is good
        pass #TODO

    def sig_no_eye(self, now):
        print("sig no eye")
        pass #TODO probs just for debugging

    def sig_direction(self, x, y):
        print("go ", x, ", ", y)
        pass #TODO

    def sig_error_reset(self):
        print("turn on error light")
        pass #TODO include turning on light, stopping wheelchair

    def sig_turn_off_error_light(self):
        print("turn off error light")
        pass #TODO

    def process_blink_commands(self, useGroups):
        print("processing ", len(useGroups), " eyes")
        pass #TODO process start, reverse, stop, and stop_reverse. with only one eye, only allow stop commands and immediately stop reverse. with no eyes, stop immediately

    def should_shut_down(self):
        return False #TODO

    def release_assets(self):
        print("releasing all assets")
        pass #TODO do things like reset the gpio